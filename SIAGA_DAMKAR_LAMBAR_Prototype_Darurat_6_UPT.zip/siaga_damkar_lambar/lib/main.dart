import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const SiagaDamkarApp());

const red = Color(0xFFC62828);
const ink = Color(0xFF18212B);
const muted = Color(0xFF647180);
const bg = Color(0xFFF4F6F8);

class Posko {
  final String kecamatan;
  final String upt;
  final String phone;
  final String piket;
  final String backup;
  final String status;
  const Posko({
    required this.kecamatan,
    required this.upt,
    this.phone = '',
    this.piket = '',
    this.backup = '',
    this.status = 'Belum diverifikasi',
  });
}

// Enam nomor diinput berdasarkan poster kontak yang dikirim pengguna.
// Sebelum rilis publik, instansi perlu mengonfirmasi kepemilikan dan kesiapan nomor.
const poskoData = <Posko>[
  Posko(kecamatan: 'Air Hitam', upt: 'Belum ada kontak pada poster'),
  Posko(kecamatan: 'Balikbukit', upt: 'UPT Balik Bukit', phone: '085129440784'),
  Posko(kecamatan: 'Bandar Negeri Suoh', upt: 'Belum ada kontak pada poster'),
  Posko(kecamatan: 'Batu Brak', upt: 'Belum ada kontak pada poster'),
  Posko(kecamatan: 'Batu Ketulis', upt: 'Belum ada kontak pada poster'),
  Posko(kecamatan: 'Belalau', upt: 'UPT Belalau', phone: '085126635816'),
  Posko(kecamatan: 'Gedung Surian', upt: 'Belum ada kontak pada poster'),
  Posko(kecamatan: 'Kebun Tebu', upt: 'UPT Kebun Tebu', phone: '082181657750'),
  Posko(kecamatan: 'Lumbok Seminung', upt: 'Belum ada kontak pada poster'),
  Posko(kecamatan: 'Pagar Dewa', upt: 'Belum ada kontak pada poster'),
  Posko(kecamatan: 'Sekincau', upt: 'Belum ada kontak pada poster'),
  Posko(kecamatan: 'Sukau', upt: 'UPT Sukau', phone: '085267346287'),
  Posko(kecamatan: 'Suoh', upt: 'Belum ada kontak pada poster'),
  Posko(kecamatan: 'Sumber Jaya', upt: 'UPT Sumber Jaya', phone: '082175439054'),
  Posko(kecamatan: 'Way Tenong', upt: 'UPT Way Tenong', phone: '082377624330'),
];

class SiagaDamkarApp extends StatelessWidget {
  const SiagaDamkarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SIAGA DAMKAR LAMBAR',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: red, primary: red),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: ink, foregroundColor: Colors.white,
          elevation: 0, centerTitle: false,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  String selectedDistrict = 'Balikbukit';

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      ContactsPage(),
      const ReportPage(),
      const SafetyPage(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(color: red, borderRadius: BorderRadius.circular(11)),
            child: const Icon(Icons.local_fire_department, color: Colors.white, size: 25),
          ),
          const SizedBox(width: 10),
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('SIAGA DAMKAR', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: .5)),
            Text('LAMPUNG BARAT', style: TextStyle(fontSize: 10, letterSpacing: 1.4, color: Color(0xFFD5DCE5))),
          ]),
        ]),
        actions: [
          IconButton(
            tooltip: 'Akses petugas',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StaffPage())),
            icon: const Icon(Icons.admin_panel_settings_outlined),
          )
        ],
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Beranda'),
          NavigationDestination(icon: Icon(Icons.call_outlined), selectedIcon: Icon(Icons.call), label: 'Kontak'),
          NavigationDestination(icon: Icon(Icons.assignment_outlined), selectedIcon: Icon(Icons.assignment), label: 'Laporan'),
          NavigationDestination(icon: Icon(Icons.shield_outlined), selectedIcon: Icon(Icons.shield), label: 'Edukasi'),
        ],
      ),
    );
  }

  void _showEmergencyContacts() {
    final activePosko = poskoData.where((p) => p.phone.isNotEmpty).toList();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('HUBUNGI POSKO DAMKAR', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: ink)),
              const SizedBox(height: 5),
              const Text('Pilih salah satu nomor posko yang tersedia. Jika mengetahui posko wilayah kejadian, hubungi posko tersebut.', style: TextStyle(color: muted, fontSize: 12, height: 1.4)),
              const SizedBox(height: 12),
              ...activePosko.map((p) => Card(
                elevation: 0,
                color: const Color(0xFFF7F8FA),
                child: ListTile(
                  leading: const CircleAvatar(backgroundColor: Color(0xFFFCE8E8), child: Icon(Icons.local_fire_department, color: red)),
                  title: Text(p.upt, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(p.phone),
                  trailing: IconButton(
                    tooltip: 'Telepon ${p.upt}',
                    icon: const Icon(Icons.call, color: red, size: 28),
                    onPressed: () async {
                      final uri = Uri(scheme: 'tel', path: p.phone);
                      if (await canLaunchUrl(uri)) {
                        await launchUrl(uri);
                      } else if (sheetContext.mounted) {
                        ScaffoldMessenger.of(sheetContext).showSnackBar(const SnackBar(content: Text('Aplikasi telepon tidak dapat dibuka.')));
                      }
                    },
                  ),
                ),
              )),
              const SizedBox(height: 6),
              const Text('Gunakan hanya untuk keadaan darurat. Jangan melakukan panggilan uji coba.', style: TextStyle(color: muted, fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _home() {
    final posko = poskoData.firstWhere((p) => p.kecamatan == selectedDistrict);
    return ListView(padding: const EdgeInsets.all(18), children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(colors: [ink, Color(0xFF303D4B)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('LAYANAN DARURAT', style: TextStyle(color: Color(0xFFFFB6B6), fontWeight: FontWeight.bold, letterSpacing: 1.5, fontSize: 11)),
          const SizedBox(height: 8),
          const Text('Butuh bantuan\nDamkar?', style: TextStyle(color: Colors.white, fontSize: 29, height: 1.1, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          const Text('Pilih wilayah kejadian untuk menemukan kontak posko yang melayani.', style: TextStyle(color: Color(0xFFD5DCE5), height: 1.4)),
          const SizedBox(height: 18),
          EmergencyNotice(onTap: _showEmergencyContacts),
        ]),
      ),
      const SizedBox(height: 20),
      const SectionTitle('Pilih wilayah kejadian', subtitle: 'Kontak akan ditampilkan berdasarkan kecamatan.'),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(
        value: selectedDistrict,
        decoration: InputDecoration(
          filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
          prefixIcon: const Icon(Icons.location_on_outlined),
        ),
        items: poskoData.map((p) => DropdownMenuItem(value: p.kecamatan, child: Text(p.kecamatan))).toList(),
        onChanged: (v) => setState(() => selectedDistrict = v ?? selectedDistrict),
      ),
      const SizedBox(height: 12),
      Card(
        elevation: 0, color: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.local_fire_department, color: red),
              const SizedBox(width: 8),
              Expanded(child: Text(posko.upt, style: const TextStyle(fontWeight: FontWeight.bold))),
              const StatusPill(),
            ]),
            const SizedBox(height: 8),
            Text('Wilayah: ${posko.kecamatan}', style: const TextStyle(color: muted)),
            const SizedBox(height: 12),
            Text(posko.phone.isEmpty ? 'Nomor kontak belum tersedia pada data yang diterima.' : 'Nomor posko: ${posko.phone}', style: const TextStyle(color: muted, fontSize: 12)),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () => setState(() => tab = 1),
              icon: const Icon(Icons.contacts_outlined),
              label: const Text('Lihat direktori posko'),
            )
          ]),
        ),
      ),
      const SizedBox(height: 18),
      const SectionTitle('Akses cepat'),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: QuickTile(icon: Icons.call, label: 'Kontak posko', onTap: () => setState(() => tab = 1))),
        const SizedBox(width: 10),
        Expanded(child: QuickTile(icon: Icons.edit_document, label: 'Buat laporan', onTap: () => setState(() => tab = 2))),
        const SizedBox(width: 10),
        Expanded(child: QuickTile(icon: Icons.health_and_safety, label: 'Tips aman', onTap: () => setState(() => tab = 3))),
      ]),
      const SizedBox(height: 18),
      const Text('Gunakan aplikasi ini untuk menghubungi layanan resmi. Jangan melakukan panggilan uji coba saat tidak ada keadaan darurat.', style: TextStyle(color: muted, fontSize: 11, height: 1.4)),
    ]);
  }
}

class EmergencyNotice extends StatelessWidget {
  final VoidCallback onTap;
  const EmergencyNotice({super.key, required this.onTap});
  @override
  Widget build(BuildContext context) => Material(
    color: red,
    borderRadius: BorderRadius.circular(15),
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(15),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: const Row(children: [
          Icon(Icons.phone_in_talk, color: Colors.white, size: 30),
          SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('PANGGIL PETUGAS DAMKAR', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13)),
            SizedBox(height: 3),
            Text('Tekan untuk memilih dan menghubungi posko', style: TextStyle(color: Colors.white, fontSize: 10)),
          ])),
          Icon(Icons.chevron_right, color: Colors.white),
        ]),
      ),
    ),
  );
}

class ContactsPage extends StatelessWidget {
  ContactsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const SectionTitle('Direktori posko', subtitle: 'Pilih wilayah untuk melihat kontak layanan.'),
    const SizedBox(height: 14),
    ...poskoData.map((p) => Card(
      elevation: 0, color: Colors.white,
      margin: const EdgeInsets.only(bottom: 9),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: const Color(0xFFFCE8E8), child: const Icon(Icons.local_fire_department, color: red)),
        title: Text(p.kecamatan, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${p.upt}\n${p.phone.isEmpty ? 'Nomor belum tersedia' : p.phone}', style: const TextStyle(height: 1.5, fontSize: 12)),
        isThreeLine: true,
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PoskoDetailPage(posko: p))),
      ),
    )),
  ]);
}

class PoskoDetailPage extends StatelessWidget {
  final Posko posko;
  const PoskoDetailPage({super.key, required this.posko});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Detail posko')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Icon(Icons.local_fire_department, color: red, size: 54),
      const SizedBox(height: 10),
      Text(posko.kecamatan, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      Text(posko.upt, style: const TextStyle(color: muted)),
      const SizedBox(height: 18),
      _contactRow('Telepon posko', posko.phone),
      _contactRow('Petugas piket', posko.piket),
      _contactRow('Nomor cadangan', posko.backup),
      const SizedBox(height: 14),
      Text(posko.phone.isEmpty ? 'Nomor kontak untuk posko ini belum tersedia pada poster yang diterima.' : 'Nomor di atas disalin dari poster kontak Damkar Lampung Barat. Pastikan nomor masih aktif dan telah disahkan instansi sebelum aplikasi disebarkan.', style: const TextStyle(color: muted, height: 1.5)),
    ]),
  );

  Widget _contactRow(String label, String number) => Card(
    elevation: 0, child: ListTile(
      title: Text(label), subtitle: Text(number.isEmpty ? 'Belum tersedia' : number),
      trailing: IconButton(
        icon: const Icon(Icons.call, color: red),
        onPressed: number.isEmpty ? null : () => launchUrl(Uri(scheme: 'tel', path: number)),
      ),
    ),
  );
}

class ReportPage extends StatefulWidget {
  const ReportPage({super.key});
  @override
  State<ReportPage> createState() => _ReportPageState();
}
class _ReportPageState extends State<ReportPage> {
  final name = TextEditingController();
  final phone = TextEditingController();
  final address = TextEditingController();
  final detail = TextEditingController();
  String type = 'Kebakaran';
  String district = 'Balikbukit';
  @override
  void dispose() { name.dispose(); phone.dispose(); address.dispose(); detail.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const SectionTitle('Laporan kejadian', subtitle: 'Formulir simulasi. Belum mengirim data ke petugas.'),
    const SizedBox(height: 14),
    _field(name, 'Nama pelapor'),
    _field(phone, 'Nomor telepon yang bisa dihubungi', keyboard: TextInputType.phone),
    DropdownButtonFormField<String>(
      value: type, decoration: const InputDecoration(labelText: 'Jenis kejadian', border: OutlineInputBorder()),
      items: ['Kebakaran', 'Penyelamatan', 'Evakuasi', 'Lainnya'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
      onChanged: (v) => setState(() => type = v ?? type),
    ),
    const SizedBox(height: 12),
    DropdownButtonFormField<String>(
      value: district, decoration: const InputDecoration(labelText: 'Kecamatan', border: OutlineInputBorder()),
      items: poskoData.map((p) => DropdownMenuItem(value: p.kecamatan, child: Text(p.kecamatan))).toList(),
      onChanged: (v) => setState(() => district = v ?? district),
    ),
    const SizedBox(height: 12),
    _field(address, 'Alamat / patokan lokasi'),
    _field(detail, 'Keterangan kejadian', maxLines: 4),
    const SizedBox(height: 14),
    FilledButton.icon(
      style: FilledButton.styleFrom(backgroundColor: red, padding: const EdgeInsets.all(15)),
      onPressed: () => showDialog(context: context, builder: (_) => AlertDialog(
        title: const Text('Prototype formulir'),
        content: const Text('Form ini belum terhubung ke server atau petugas. Jangan mengandalkannya untuk melaporkan keadaan darurat. Gunakan nomor resmi Damkar yang telah diverifikasi.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Mengerti'))],
      )),
      icon: const Icon(Icons.send), label: const Text('Kirim laporan (simulasi)'),
    ),
    const SizedBox(height: 10),
    const Text('Untuk kejadian yang sedang berlangsung, utamakan panggilan telepon ke nomor resmi yang telah dikonfirmasi.', style: TextStyle(color: muted, fontSize: 11, height: 1.4)),
  ]);
  Widget _field(TextEditingController c, String label, {TextInputType? keyboard, int maxLines = 1}) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextField(controller: c, keyboardType: keyboard, maxLines: maxLines, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder())),
  );
}

class SafetyPage extends StatelessWidget {
  const SafetyPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: const [
    SectionTitle('Edukasi keselamatan', subtitle: 'Informasi dasar pencegahan dan respons kebakaran.'),
    SizedBox(height: 14),
    SafetyCard(icon: Icons.electrical_services, title: 'Cegah korsleting listrik', body: 'Hindari penggunaan stopkontak bertumpuk, periksa kabel yang rusak, dan gunakan instalasi sesuai standar.'),
    SafetyCard(icon: Icons.local_fire_department, title: 'Jika terjadi kebakaran', body: 'Tetap tenang, beri peringatan kepada orang sekitar, evakuasi melalui jalur aman, dan jangan kembali ke bangunan yang terbakar.'),
    SafetyCard(icon: Icons.fire_extinguisher, title: 'Gunakan APAR dengan aman', body: 'Gunakan APAR hanya jika api masih kecil, jalur keluar tetap tersedia, dan Anda telah memahami cara penggunaannya.'),
    SafetyCard(icon: Icons.smoke_free, title: 'Utamakan evakuasi', body: 'Jangan menghirup asap. Bergerak merunduk jika harus melewati area berasap dan segera menuju titik aman.'),
  ]);
}

class StaffPage extends StatelessWidget {
  const StaffPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Akses petugas')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Icon(Icons.admin_panel_settings, color: red, size: 52),
      const SizedBox(height: 12),
      const Text('Area petugas', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      const Text('Dashboard ini masih berupa rancangan antarmuka. Login dan hak akses belum diaktifkan.', style: TextStyle(color: muted, height: 1.5)),
      const SizedBox(height: 18),
      const StaffTile(icon: Icons.assignment, title: 'Laporan masuk', subtitle: 'Daftar laporan masyarakat (belum terhubung)'),
      const StaffTile(icon: Icons.schedule, title: 'Jadwal piket', subtitle: 'Pengelolaan petugas jaga (belum terhubung)'),
      const StaffTile(icon: Icons.contact_phone, title: 'Kelola nomor posko', subtitle: 'Pembaruan kontak resmi (belum terhubung)'),
      const StaffTile(icon: Icons.toggle_on, title: 'Status kesiapsiagaan', subtitle: 'Status posko dan armada (belum terhubung)'),
    ]),
  );
}

class StaffTile extends StatelessWidget {
  final IconData icon; final String title; final String subtitle;
  const StaffTile({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Card(elevation: 0, child: ListTile(leading: Icon(icon, color: red), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(subtitle)));
}
class SafetyCard extends StatelessWidget {
  final IconData icon; final String title; final String body;
  const SafetyCard({super.key, required this.icon, required this.title, required this.body});
  @override
  Widget build(BuildContext context) => Card(
    elevation: 0, margin: const EdgeInsets.only(bottom: 11),
    child: Padding(padding: const EdgeInsets.all(16), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: red, size: 27), const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 5), Text(body, style: const TextStyle(color: muted, height: 1.45)),
      ]))
    ])),
  );
}
class SectionTitle extends StatelessWidget {
  final String title; final String? subtitle;
  const SectionTitle(this.title, {super.key, this.subtitle});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: ink)),
    if (subtitle != null) ...[const SizedBox(height: 4), Text(subtitle!, style: const TextStyle(color: muted, fontSize: 12))],
  ]);
}
class StatusPill extends StatelessWidget {
  const StatusPill({super.key});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
    decoration: BoxDecoration(color: const Color(0xFFFFF1D6), borderRadius: BorderRadius.circular(30)),
    child: const Text('Verifikasi', style: TextStyle(color: Color(0xFF8A5A00), fontSize: 10, fontWeight: FontWeight.bold)),
  );
}
class QuickTile extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const QuickTile({super.key, required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(14), onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 7),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
      child: Column(children: [Icon(icon, color: red, size: 24), const SizedBox(height: 7), Text(label, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 10))]),
    ),
  );
}
