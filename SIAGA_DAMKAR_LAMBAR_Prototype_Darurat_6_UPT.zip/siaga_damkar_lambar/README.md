# SIAGA DAMKAR LAMBAR — Prototype Android

Prototype awal Flutter untuk aplikasi layanan Pemadam Kebakaran dan Penyelamatan Kabupaten Lampung Barat.

## Isi prototype
- Beranda layanan darurat.
- Direktori 15 kecamatan.
- Detail posko dan tombol telepon (aktif setelah nomor diisi).
- Formulir laporan simulasi.
- Halaman edukasi keselamatan.
- Rancangan area petugas.

## Status dan batasan
Ini adalah prototype antarmuka, belum aplikasi operasional.
- Nomor telepon sengaja dikosongkan karena harus dimasukkan dari daftar resmi dan diverifikasi.
- Form laporan belum mengirim data ke server.
- Login petugas, database, GPS, notifikasi, dan dashboard admin belum diintegrasikan.
- Status operasional/siaga tidak boleh dianggap real-time.

## Cara menjalankan
1. Pasang Flutter SDK dan Android Studio.
2. Ekstrak ZIP ini.
3. Buka terminal pada folder `siaga_damkar_lambar`.
4. Jalankan:
   ```bash
   flutter pub get
   flutter run
   ```
5. Untuk membuat APK debug:
   ```bash
   flutter build apk --debug
   ```
   APK akan berada di `build/app/outputs/flutter-apk/app-debug.apk`.

## Memasukkan nomor posko
Edit daftar `poskoData` pada `lib/main.dart`.
Isi `phone`, `piket`, dan `backup` menggunakan nomor resmi yang telah disetujui instansi, dengan format internasional atau nasional yang sesuai, misalnya `+62812...` atau `08...`.
Jangan memasukkan nomor pribadi petugas tanpa persetujuan dan tetapkan petugas/admin yang berwenang memperbaruinya.

## Data wilayah
Daftar 15 kecamatan disediakan sebagai kerangka awal. Penetapan UPT/posko pelayan untuk setiap kecamatan perlu diverifikasi oleh Damkar Lampung Barat sebelum rilis.

## Tahap berikutnya
- Validasi daftar kecamatan, wilayah pelayanan, dan nomor darurat.
- Buat backend dan autentikasi berbasis peran.
- Bangun dashboard admin untuk nomor posko, petugas piket, armada, dan laporan.
- Tambahkan GPS/lokasi, notifikasi, pencatatan audit, dan uji keamanan.
- Uji coba terbatas dengan persetujuan instansi.


## Build APK tanpa laptop (menggunakan HP + GitHub Actions)
1. Buat akun GitHub, lalu buat repository baru bernama `siaga-damkar-lambar`.
2. Unggah seluruh isi folder proyek ini ke repository (termasuk folder tersembunyi `.github/workflows` dan file `build-apk.yml`).
3. Buka tab **Actions** pada repository.
4. Pilih workflow **Build Android APK**, lalu tekan **Run workflow**. Jika workflow tidak muncul, pastikan file `.github/workflows/build-apk.yml` sudah ikut terunggah dan buka ulang tab Actions.
5. Tunggu proses selesai dengan tanda hijau.
6. Buka hasil workflow, cari bagian **Artifacts**, lalu unduh `siaga-damkar-lambar-apk`.
7. Ekstrak ZIP artifact tersebut. Di dalamnya ada `app-release.apk`. Unduh dan pasang di HP untuk uji coba.

Catatan:
- Build dilakukan di server GitHub, bukan di HP.
- Repository dapat dibuat private. Jangan mengunggah nomor pribadi petugas atau data sensitif ke repository publik.
- File APK hasil build masih prototype: nomor kontak kosong, laporan belum mengirim ke server, dan login petugas belum aktif.
- Untuk distribusi resmi, APK perlu diuji, ditandatangani dengan kunci rilis yang dikelola aman, dan disetujui instansi.


## Kontak posko yang dimasukkan dari poster pengguna
- UPT Balik Bukit: 085129440784
- UPT Belalau: 085126635816
- UPT Sukau: 085267346287
- UPT Way Tenong: 082377624330
- UPT Kebun Tebu: 082181657750
- UPT Sumber Jaya: 082175439054

Nomor diinput sebagai data dari poster dan belum diverifikasi secara independen. Konfirmasi ke instansi sebelum distribusi publik. Kecamatan lain tetap ditampilkan, tetapi nomor belum tersedia.

## Tombol panggilan darurat
Pada beranda, tombol merah **PANGGIL PETUGAS DAMKAR** membuka daftar enam UPT yang memiliki nomor pada poster. Pengguna memilih UPT lalu menekan ikon telepon untuk membuka aplikasi panggilan perangkat. Aplikasi tidak otomatis menentukan posko terdekat atau wilayah tanggung jawab karena pemetaan cakupan belum diberikan.
