# SIAGA DAMKAR LAMBAR

Prototipe Flutter untuk aplikasi layanan Damkar Lampung Barat.

## Build APK melalui GitHub Actions
Unggah isi proyek ini ke repositori GitHub (termasuk folder `.github/workflows`), lalu buka tab Actions dan jalankan workflow **Build Android APK**. APK uji dapat diunduh dari bagian Artifacts.

## Status
Ini masih prototipe. Fitur laporan belum tersambung ke server; login petugas, database, GPS, dan notifikasi belum dibuat. Pastikan seluruh nomor kontak diverifikasi oleh instansi sebelum aplikasi dipublikasikan.
