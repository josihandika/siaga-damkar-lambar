import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const SiagaDamkarApp());

class SiagaDamkarApp extends StatelessWidget {
  const SiagaDamkarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SIAGA DAMKAR LAMBAR',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFC62828)),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class Posko {
  final String name;
  final String phone;
  const Posko(this.name, this.phone);
}

const poskos = <Posko>[
  Posko('UPT Balik Bukit', '085129440784'),
  Posko('UPT Belalau', '085126635816'),
  Posko('UPT Sukau', '085267346287'),
  Posko('UPT Way Tenong', '082377624330'),
  Posko('UPT Kebun Tebu', '082181657750'),
  Posko('UPT Sumber Jaya', '082175439054'),
];

Future<void> callNumber(String phone) async {
  final uri = Uri(scheme: 'tel', path: phone);
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri);
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFC62828),
        foregroundColor: Colors.white,
        title: const Text('SIAGA DAMKAR LAMBAR', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF202124),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('PEMADAM KEBAKARAN & PENYELAMATAN',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
                SizedBox(height: 8),
                Text('Kabupaten Lampung Barat', style: TextStyle(color: Colors.white70)),
                SizedBox(height: 8),
                Text('Akses cepat layanan darurat dan kontak posko Damkar.',
                    style: TextStyle(color: Colors.white)),
              ],
            ),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFFC62828),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 20),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            onPressed: () => showModalBottomSheet(
              context: context,
              builder: (_) => const PoskoSheet(),
            ),
            icon: const Icon(Icons.phone_in_talk, size: 26),
            label: const Text('PANGGIL DAMKAR', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 22),
          const Text('Kontak Posko', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...poskos.map((p) => Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.local_fire_department)),
              title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(p.phone),
              trailing: IconButton(
                tooltip: 'Telepon',
                icon: const Icon(Icons.call, color: Color(0xFFC62828)),
                onPressed: () => callNumber(p.phone),
              ),
            ),
          )),
          const SizedBox(height: 14),
          const Text('Catatan: prototipe ini belum mengirim laporan ke server dan belum memiliki login petugas atau basis data. Nomor kontak perlu diverifikasi instansi sebelum dipublikasikan.',
              style: TextStyle(color: Colors.black54, fontSize: 12)),
        ],
      ),
    );
  }
}

class PoskoSheet extends StatelessWidget {
  const PoskoSheet({super.key});
  @override
  Widget build(BuildContext context) => SafeArea(
    child: ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Pilih Posko Damkar', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ...poskos.map((p) => ListTile(
          title: Text(p.name),
          subtitle: Text(p.phone),
          trailing: const Icon(Icons.call),
          onTap: () {
            Navigator.pop(context);
            callNumber(p.phone);
          },
        )),
      ],
    ),
  );
}
